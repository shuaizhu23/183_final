# single sign on Google (will be used if provided)
OAUTH2GOOGLE_CLIENT_ID = "78455142332-jsurrecdmnk74clan8st729dp8p74rdl.apps.googleusercontent.com"
OAUTH2GOOGLE_CLIENT_SECRET = "kQ3tL24Qyr9qRYnI7sdTjaZb"

DB_USER = "appuser"
DB_NAME = "sampledb"
DB_PASSWORD = "appuser1"
DB_CONNECTION = "platinum-factor-318523:us-west1:shuai-sample-db-1"

#  root udIJsgHvfscxpq85
